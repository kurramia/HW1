import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
    private static Animal createAnimal(Scanner scanner, String type) {
        System.out.print("Введите животное: ");
        String breed = scanner.nextLine();

        System.out.print("Введите имя: ");
        String name = scanner.nextLine();

        System.out.print("Введите цену: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Считываем оставшийся перевод строки

        System.out.print("Введите характер: ");
        String character = scanner.nextLine();

        if (type.equalsIgnoreCase("Pet")) {
            return new Pet(breed, name, price, character);
        } else {
            return new Predator(breed, name, price, character);
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Animal pet = createAnimal(scanner, "Pet");
        Animal predator = createAnimal(scanner, "Predator");

        System.out.println(pet.getName() + ": " + pet.getCharacter());
        System.out.println(predator.getName() + ": " + predator.getCharacter());

        // Создание животных
        System.out.println("Создание уникальных животных:");
        pet.createUniqueAnimals();

        System.out.print("Введите количество животных для создания: ");
        int N = scanner.nextInt();
        pet.createNAnimals(N);

        System.out.println("Создание животных с использованием do-while:");
        pet.createAnimalsUsingDoWhile();

        scanner.close();
    }

}

