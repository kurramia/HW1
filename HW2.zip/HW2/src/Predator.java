import java.time.LocalDate;

public class Predator extends  AbstractAnimal{
    public Predator(String breed, String name, double cost, String character){
        super(breed, name, cost, character);
    }

}
