import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public interface Animal {
    String getBreed();
    String getName();
    double getCost();
    String getCharacter();

    default void createUniqueAnimals() {
        Set<String> uniqueNames = new HashSet<>();
        int count = 0;

        while (count < 10) {
            String name = "Animal" + (count + 1);
            if (uniqueNames.add(name)) {
                System.out.println("Создано уникальное животное: " + name);
                count++;
            }
        }
    }

    default void createNAnimals(int N) {
        for (int i = 0; i < N; i++) {
            System.out.println("Создано животное: Animal" + (i + 1));
        }
    }

    default void createAnimalsUsingDoWhile() {
        int count = 0;
        do {
            count++;
            System.out.println("Создано животное: Animal" + count);
        } while (count < 10);
    }

    private static Animal createAnimal(Scanner scanner, String type) {
        System.out.print("Введите породу: ");
        String breed = scanner.nextLine();

        System.out.print("Введите имя: ");
        String name = scanner.nextLine();

        System.out.print("Введите цену: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Считываем оставшийся перевод строки

        System.out.print("Введите характер: ");
        String character = scanner.nextLine();

        if (type.equalsIgnoreCase("Pet")) {
            return new Pet(breed, name, price, character);
        } else {
            return new Predator(breed, name, price, character);
        }
    }
}
