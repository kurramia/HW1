import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class Predator extends  AbstractAnimal{
    public Predator(String breed, String name, double cost, String character, LocalDate birthDate){
        super(breed, name, cost, character, birthDate);
    }
}
