
public class Pet extends AbstractAnimal {

    public Pet(String breed, String name, double cost, String character){
        super(breed, name, cost, character);
    }

}
