public class Main {
    public static void main(String[] args) {
        Pet hamster = new Pet("Хомяк", "Гоша", 300, "Пугливый");
        Pet parrot = new Pet("Попугай", "Павлуша", 500, "Общительный");
        Predator lion = new Predator("Африканский лев", "Тигр", 1500, "Грозный");
        Predator tiger = new Predator("Амурский тигр", "Лев", 5000, "Спокойный");


    }
}



