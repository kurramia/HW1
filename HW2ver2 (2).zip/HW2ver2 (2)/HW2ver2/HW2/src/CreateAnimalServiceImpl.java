import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class CreateAnimalServiceImpl extends CreateAnimalService{

    public void createAnimals(int n) {
        for (int i = 0; i < n; i++) {
            String name = "Animal" + random.nextInt(100);
            if (uniqueNames.add(name)) {
                Animal animal = createAnimal(name);
                System.out.println(animal);
            }
        }
    }

    public void createAnimalsWithDoWhile() {
        do {
            String name = "Animal" + random.nextInt(100);
            if (uniqueNames.add(name)) {
                Animal animal = createAnimal(name);
                System.out.println(animal);
            }
        } while (uniqueNames.size() < 10);
    }

    public static void main(String[] args) {
        CreateAnimalServiceImpl service = new CreateAnimalServiceImpl();

        System.out.println("Creating 10 animals using while:");
        service.createAnimals();

        System.out.println("\nCreating 5 animals using for:");
        service.createAnimals(5);

        System.out.println("\nCreating 10 animals using do-while:");
        service.createAnimalsWithDoWhile();
    }
}
