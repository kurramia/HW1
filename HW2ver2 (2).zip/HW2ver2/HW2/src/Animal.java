import java.util.HashSet;
import java.util.Set;
import java.util.Random;

public interface Animal {
    String getBreed();
    String getName();
    double getCost();
    String getCharacter();

    default void createUniqueAnimals() {
        Set<String> uniqueNames = new HashSet<>();
        Random random = new Random();
        int count = 0;

        while (count < 10) {
            String name = "Animal" + (count + 1);
            if (uniqueNames.add(name)) {
                System.out.println("Создано уникальное животное: " + name);
                count++;
            }
        }
    }

    default void createNAnimals(int N) {
        for (int i = 0; i < N; i++) {
            System.out.println("Создано животное: Animal" + (i + 1));
        }
    }

    default void createAnimalsUsingDoWhile() {
        int count = 0;
        do {
            count++;
            System.out.println("Создано животное: Animal" + count);
        } while (count < 10);
    }
}
