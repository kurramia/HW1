import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

interface Animal {
    String getBreed();
    String getName();
    double getPrice();
    String getCharacter();
    LocalDate getBirthDate();

    boolean equals(Object obj);

}
