import java.time.LocalDate;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
abstract class AbstractAnimal implements Animal {
    protected String breed;
    protected String name;
    protected double price;
    protected String character;
    protected LocalDate birthDate;
    public AbstractAnimal(String name, String breed, double price, String character, LocalDate birthDate) {
        this.name = name;
        this.breed = breed;
        this.price = price;
        this.character = character;
        this.birthDate = birthDate;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getBreed() {
        return breed;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getCharacter() {
        return character;
    }

    @Override
    public LocalDate getBirthDate() {
        return birthDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        AbstractAnimal that = (AbstractAnimal) obj;
        return Double.compare(that.price, price) == 0 &&
                name.equals(that.name) &&
                breed.equals(that.breed) &&
                character.equals(that.character) &&
                birthDate.isEqual(that.birthDate);
    }

}
