import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class SearchServiceImpl implements SearchService {
    @Override
    public String[] findLeapYearNames(Animal[] animals) {
        return Arrays.stream(animals)
                .filter(a -> (a.getBirthDate().getYear() % 4 == 0 && (a.getBirthDate().getYear() % 100 != 0 || a.getBirthDate().getYear() % 400 == 0)))
                .map(Animal::getName)
                .toArray(String[]::new);
    }

    @Override
    public Animal[] findOlderAnimal(Animal[] animals, int age) {
        LocalDate cutoffDate = LocalDate.now().minusYears(age);
        return Arrays.stream(animals)
                .filter(a -> a.getBirthDate().isBefore(cutoffDate))
                .toArray(Animal[]::new);
    }

    @Override
    public void findDuplicate(Animal[] animals) {
        Set<Animal> seen = new HashSet<>();
        for (Animal animal : animals) {
            if (!seen.add(animal)) {
                System.out.println("Дубликат найден: " + animal.getName());
            }
        }
    }
}
