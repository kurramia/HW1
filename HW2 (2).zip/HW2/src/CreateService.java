import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class CreateService {
    public Animal[] createAnimals(int count) {
        Animal[] animals = new Animal[count];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < count; i++) {
            System.out.print("Введите имя: ");
            String name = scanner.next();
            System.out.print("Введите породу: ");
            String breed = scanner.next();
            System.out.print("Введите цену: ");
            double price = scanner.nextDouble();
            System.out.print("Введите характер: ");
            String character = scanner.next();
            LocalDate birthDate = LocalDate.of(2020, 1, 1).plusDays((int)(Math.random() * 365)); // Генерация случайной даты
            animals[i] = new Pet(name, breed, price, character, birthDate);
            System.out.println("Создано животное: " + animals[i].getName());
        }
        return animals;
    }
}
