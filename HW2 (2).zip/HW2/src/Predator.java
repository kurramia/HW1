import java.time.LocalDate;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

class Predator extends AbstractAnimal {
    public Predator(String name, String breed, double price, String character, LocalDate birthDate) {
        super(name, breed, price, character, birthDate);
    }
}
