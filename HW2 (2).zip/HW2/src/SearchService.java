import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
public interface SearchService {
    String[] findLeapYearNames(Animal[] animals);
    Animal[] findOlderAnimal(Animal[] animals, int age);
    void findDuplicate(Animal[] animals);
}
