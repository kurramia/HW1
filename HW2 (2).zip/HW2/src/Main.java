import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        CreateService createService = new CreateService();
        Animal[] animals = createService.createAnimals(10); // Создание 10 животных

        SearchService searchService = new SearchServiceImpl();

        System.out.println("Животные, родившиеся в високосный год: " + Arrays.toString(searchService.findLeapYearNames(animals)));
        System.out.println("Животные старше 5 лет: " + Arrays.toString(searchService.findOlderAnimal(animals, 5)));
        searchService.findDuplicate(animals);
    }

}

