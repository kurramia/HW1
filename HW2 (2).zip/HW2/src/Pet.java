import java.time.LocalDate;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
class Pet extends AbstractAnimal {
    public Pet(String name, String breed, double price, String character, LocalDate birthDate) {
        super(name, breed, price, character, birthDate);
    }
}
